#pragma once
#include "foeplane.h"
class bigfoeplane :
	public foeplane
{
public:
	bigfoeplane(void);
	~bigfoeplane(void);
		  virtual bool isgunnerfoeplane(gunner*pgunner);
	 virtual bool ishitplayer(player&plane);
	 virtual void initfoepalne(HINSTANCE hins);
	 virtual void showfoeplane(HDC hdc);
	 virtual void movefoeplane();
};

