#include "background.h"


background::background(void)
{
		 m_backdown=0;
		 m_backup=0;
	     x=0;
	     y=0;
}


background::~background(void)
{
	DeleteObject(m_backdown);
		 m_backdown=0;
		 	DeleteObject(m_backup);
		 m_backup=0;
}
 void background::initback(HINSTANCE hins)
 {
	 m_backdown=LoadBitmap(hins,MAKEINTRESOURCE(IDB_back));
	 m_backup=LoadBitmap(hins,MAKEINTRESOURCE(IDB_back));
 }
    void background::moveback()
	{
		 
		if(y>550)
		{
      y=0;
		}
		else
			y++;

	}
    void background::showback(HDC hdc)
	{
		HDC menhdc =CreateCompatibleDC(hdc);
		SelectObject(menhdc,m_backup);
		BitBlt(hdc,x,y-550,380,550,menhdc,0,0,SRCCOPY);
		SelectObject(menhdc,m_backdown);
		BitBlt(hdc,x,y,380,550,menhdc,0,0,SRCCOPY);
		DeleteDC(menhdc);
	}