#pragma once
#include<windows.h>
#include<list>
#include<algorithm>
#include"resource.h"
using namespace std;
#define Tback 1
#define  playermove 2
#define  gunnermove 3
#define  addgunner  4
#define  foemove  5
#define  addfoe  6
#define boomshow 7