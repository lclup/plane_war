#pragma once
#include"sys.h"
#include"gunnerbox.h"
#include"gunner.h"
class player
{
public:
	player(void);
	~player(void);
public:
	 HBITMAP m_player;
	 int m_gunnertype;
	int x;
	int y;
public:
	 void initplayer(HINSTANCE hins);
	 void moveplayer(int fx);
	 void sendgunner(HINSTANCE hins,gunnerbox&gunnerb);
	 void showplayer(HDC hdc);
};

