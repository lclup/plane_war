#pragma once
#include"sys.h"
class gunner
{
public:
	gunner(void);
	~gunner(void);
public:
	HBITMAP m_gunner;
	int x;
	int y;
public:
   void initgunner(HINSTANCE hins,int x1,int y1);
   void movegunnner();
   void showgunner(HDC hdc);
};

