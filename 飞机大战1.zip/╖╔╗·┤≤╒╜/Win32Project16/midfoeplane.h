#pragma once
#include "foeplane.h"
class midfoeplane :
	public foeplane
{
public:
	midfoeplane(void);
	~midfoeplane(void);
public:
	  bool isgunnerfoeplane(gunner*pgunner);
	 bool ishitplayer(player&plane);
	 void initfoepalne(HINSTANCE hins);
	 void showfoeplane(HDC hdc);
	 void movefoeplane();
	 
};

