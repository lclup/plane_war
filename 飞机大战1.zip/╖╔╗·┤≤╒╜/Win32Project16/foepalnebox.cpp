#include "foepalnebox.h"


foepalnebox::foepalnebox(void)
{
}


foepalnebox::~foepalnebox(void)
{
		list<foeplane*> ::iterator ito=m_foeplane.begin();
		while( ito!=m_foeplane.end())
		{
delete(*ito);
ito=m_foeplane.erase(ito);
		}
}
	void foepalnebox::allmove()
	{
	list<foeplane*> ::iterator ito=m_foeplane.begin();
		while( ito!=m_foeplane.end())
		{
 (*ito)->movefoeplane();
    ito++;
		}
	}
	 void foepalnebox::allshow(HDC hdc)
	 {
		 list<foeplane*> ::iterator ito=m_foeplane.begin();
		while( ito!=m_foeplane.end())
		{
 (*ito)->showfoeplane(hdc);
    ito++;
		}
	 }
	 void foepalnebox::ctreatefoeplane(HINSTANCE hins)
	 {
		 switch(rand()%3)
		 {
		 case 0:
			 {
			 foeplane *foe=new midfoeplane;
			 foe->initfoepalne(hins);
			 m_foeplane.push_back(foe);
			 }
			 break;
		 case 1:
			 {
			  foeplane *foe=new bigfoeplane;
			 foe->initfoepalne(hins);
			 m_foeplane.push_back(foe);
			 }
			 break;
		 case 2:
			 {
			   foeplane *foe=new smallfoeplane;
			 foe->initfoepalne(hins);
			 m_foeplane.push_back(foe);
			 }
			 break;

		 }
	 }
