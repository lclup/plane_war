#include "bigfoeplane.h"


bigfoeplane::bigfoeplane(void)
{
}


bigfoeplane::~bigfoeplane(void)
{
}
bool bigfoeplane::isgunnerfoeplane(gunner*pgunner)
  {
	   if(pgunner->x>=x&&pgunner->x<=x+108&&pgunner->y>=y&&pgunner->y<=y+128)
	  return true;
	 return false;
 
  }
  bool bigfoeplane::ishitplayer(player&plane)
  {
	  //x+30,y
	      if(plane.x+30>=x&&plane.x+30<=x+108&&plane.y>=y&&plane.y<=y+128)
	   {
		   return true;
	   }
	   //x+60.y+50
		      if(plane.x+60>=x&&plane.x+60<=x+108&&plane.y+50>=y&&plane.y+50<=y+128)
	   {
		   return true;
	   }
	   //x,y+50;
	   if(plane.x>=x&&plane.x<=x+108&&plane.y+50>=y&&plane.y+50<=y+128)
	   {
		   return true;
	   }
	   return false;
  }
  void bigfoeplane::initfoepalne(HINSTANCE hins)
  {
x=rand()%272;
y=-128;
showID=3;
blood=5;
bitfoeplane=LoadBitmap(hins,MAKEINTRESOURCE(IDB_big));
  }
  void bigfoeplane::showfoeplane(HDC hdc)
  {
	  HDC hdcmen=CreateCompatibleDC(hdc);
	  SelectObject(hdcmen,bitfoeplane);
	  BitBlt(hdc,x,y,108,128,hdcmen,0,(3-showID)*128,SRCAND);
	  DeleteDC(hdcmen);
  }
  void bigfoeplane::movefoeplane()
  {
y=y+2;
  }
