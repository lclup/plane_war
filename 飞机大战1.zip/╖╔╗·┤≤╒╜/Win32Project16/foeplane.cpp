#include "foeplane.h"


foeplane::foeplane(void)
{
  bitfoeplane=0;
	  blood=0;
	  showID=0;
	 x=0;
	 y=0;
}


foeplane::~foeplane(void)
{
	DeleteObject(bitfoeplane);
	  bitfoeplane=0;
}
 bool foeplane::isboom()
 {
	 if(blood==0)
	 return true;
	 return false;
 }
  bool foeplane::isgunnerfoeplane(gunner*pgunner)
  {
return true;
  }
  bool foeplane::ishitplayer(player&plane)
  {
	  return true;
  }
  void foeplane::initfoepalne(HINSTANCE hins)
  {

  }
  void foeplane::showfoeplane(HDC hdc)
  {

  }
  void foeplane::movefoeplane()
  {

  }
	 void foeplane:: downblood()
	 {
		 blood--;
	 }

