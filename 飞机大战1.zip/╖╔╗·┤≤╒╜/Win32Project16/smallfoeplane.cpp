#include "smallfoeplane.h"


smallfoeplane::smallfoeplane(void)
{
}


smallfoeplane::~smallfoeplane(void)
{
}
bool smallfoeplane::isgunnerfoeplane(gunner*pgunner)
  {
	   if(pgunner->x>=x&&pgunner->x<=x+34&&pgunner->y>=y&&pgunner->y<=y+28)
	  return true;
	 return false;
	  
  }
  bool smallfoeplane::ishitplayer(player&plane)
  {
	    //x+30,y
	      if(plane.x+30>=x&&plane.x+30<=x+34&&plane.y>=y&&plane.y<=y+28)
	   {
		   return true;
	   }
	   //x+60.y+50
		      if(plane.x+60>=x&&plane.x+60<=x+34&&plane.y+50>=y&&plane.y+50<=y+28)
			  {
		   return true;
	   }
	   //x,y+50;
	   if(plane.x>=x&&plane.x<=x+34&&plane.y+50>=y&&plane.y+50<=y+28)
	   {
		   return true;
	   }
	   return false;
  }
  void smallfoeplane::initfoepalne(HINSTANCE hins)
  {
x=rand()%346;
y=-28;
blood=1;
showID=1;
bitfoeplane=LoadBitmap(hins,MAKEINTRESOURCE(IDB_small));
  }
  void smallfoeplane::showfoeplane(HDC hdc)
  {
	  HDC hdcmen=CreateCompatibleDC(hdc);
	  SelectObject(hdcmen,bitfoeplane);
	  BitBlt(hdc,x,y,34,28,hdcmen,0,(1-showID)*28,SRCAND);
	  DeleteDC(hdcmen);
  }
  void smallfoeplane::movefoeplane()
  {
y=y+6;
  }
