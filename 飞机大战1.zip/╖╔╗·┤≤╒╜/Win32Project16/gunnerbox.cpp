#include "gunnerbox.h"


gunnerbox::gunnerbox(void)
{
}


gunnerbox::~gunnerbox(void)
{
	list<gunner*>::iterator ito=m_gunner.begin();
	while(ito!=m_gunner.end())
	{
		delete(*ito);
		ito=m_gunner.erase(ito);
	}
}
 void gunnerbox::allgunnermove()
 {
	 list<gunner*>::iterator ito=m_gunner.begin();
	while(ito!=m_gunner.end())
	{
		 (*ito)->movegunnner();
		ito++;
	}
 }
	 void gunnerbox::allshowgunner(HDC hdc)
	 {
		  list<gunner*>::iterator ito=m_gunner.begin();
	while(ito!=m_gunner.end())
	{
		 (*ito)->showgunner(hdc);
		ito++;
	}
	 }
 
