#include "foeboombox.h"


foeboombox::foeboombox(void)
{
}


foeboombox::~foeboombox(void)
{
 
	list<foeplane*>::iterator ito=m_boomplane.begin();
	while(ito!=m_boomplane.end())
	{
		delete(*ito);
		ito=m_boomplane.erase(ito);
	}
}
 void foeboombox::allboomshow(HDC hdc)
 {
	list<foeplane*>::iterator ito=m_boomplane.begin();
	while(ito!=m_boomplane.end())
	{

		(*ito)->showfoeplane(hdc);
		 ito++;
	}

 }
	  void foeboombox::changeshowID()
	  {
		  	list<foeplane*>::iterator ito=m_boomplane.begin();
	while(ito!=m_boomplane.end())
	{

		if((*ito)->showID==0)
		{
			delete(*ito);
			ito=m_boomplane.erase(ito);
		}
		else
		{
			(*ito)->showID--;
		 ito++;
		}
	}

	  }
