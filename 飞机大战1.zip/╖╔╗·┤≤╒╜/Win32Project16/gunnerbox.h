#pragma once
#include"gunner.h"
#include"sys.h"
class gunnerbox
{
public:
	gunnerbox(void);
	~gunnerbox(void);
public:
	list<gunner*> m_gunner;
public:
	 void allgunnermove();
	 void allshowgunner(HDC hdc);
};

