#include "planeapp.h"
declass(planeapp)

planeapp::planeapp(void)
{
}


planeapp::~planeapp(void)
{
}
 bool planeapp::isgameover()
 {
	 list<foeplane*>::iterator ito=foeplaneboxx.m_foeplane.begin();
	 while(ito!=foeplaneboxx.m_foeplane.end())
	 {
	 if((*ito)->ishitplayer(playerr))
	 return true;
	  
	 ito++;
 }
	 return false;
 }
    void planeapp:: creategame()
   {
	   SetTimer(m_hwnd,Tback,100,0);
	   SetTimer(m_hwnd,playermove,50,0);
	   SetTimer(m_hwnd,gunnermove,30,0);
	   SetTimer(m_hwnd,addgunner,200,0);
	   SetTimer(m_hwnd,foemove,50,0);
	   SetTimer(m_hwnd,addfoe,1000,0);
	   SetTimer(m_hwnd,boomshow,100,0);
	   backk.initback(m_hins);
	   playerr.initplayer(m_hins);

   }
  void planeapp::  drawgame()
  {
	  PAINTSTRUCT ps={0};
	  HDC hdc=BeginPaint(m_hwnd,&ps);
	  HDC menhdc= CreateCompatibleDC(hdc);
	  HBITMAP bitmap=CreateCompatibleBitmap(hdc,380,550);
	  SelectObject(menhdc,bitmap);
	  backk.showback(menhdc);
	  playerr.showplayer(menhdc);
	  foeboomboxx.allboomshow(menhdc);
	  gunnerboxx.allshowgunner(menhdc);
	  foeplaneboxx.allshow(menhdc);
	  BitBlt(hdc,0,0,380,550,menhdc,0,0,SRCCOPY);
	  DeleteDC(menhdc);
	  DeleteObject(bitmap);
	  EndPaint(m_hwnd,&ps);
  }
  void planeapp::  keydowngame(WPARAM pa)
  {
	 
  }
  void planeapp::  rungame(WPARAM wp)
   {
	   if(Tback==wp)
	   {
backk.moveback();
	   }
	   if(playermove==wp)
	   {
		   if(GetAsyncKeyState(VK_UP))
		   playerr.moveplayer(VK_UP);
		    if(GetAsyncKeyState(VK_DOWN))
		   playerr.moveplayer(VK_DOWN);
			 if(GetAsyncKeyState(VK_LEFT))
		   playerr.moveplayer(VK_LEFT);
			  if(GetAsyncKeyState(VK_RIGHT))
		   playerr.moveplayer(VK_RIGHT);

	   }
	   if(gunnermove==wp)
	   {
		   gunnerboxx.allgunnermove();
		   gunnerhitplane();

	   }
	   if(boomshow==wp)
	   {
		   foeboomboxx.changeshowID();
	   }
	   if(addgunner==wp)
	   {
 playerr.sendgunner(m_hins,gunnerboxx);
	   }
	   if(foemove==wp)
	   {
foeplaneboxx.allmove();
if(isgameover())
{
      KillTimer(m_hwnd,Tback );
	  KillTimer(m_hwnd,playermove);
	  KillTimer(m_hwnd,gunnermove );
	  KillTimer(m_hwnd,addgunner );
	  KillTimer(m_hwnd,foemove );
	  KillTimer(m_hwnd,addfoe );
	  KillTimer(m_hwnd,boomshow );
  MessageBox(0,"gameover","��ʾ",MB_OK);
}	 
	   }
	   if(addfoe==wp)
	   {
foeplaneboxx.ctreatefoeplane(m_hins);
	   }
	   RECT rect={0,0,380,550};
	   InvalidateRect(m_hwnd,&rect,FALSE);

   }
   void planeapp::gunnerhitplane()
   {
	   bool flag=true;
list<gunner*>::iterator ito=gunnerboxx.m_gunner.begin();
while(ito!=gunnerboxx.m_gunner.end())
{
list<foeplane*>::iterator itoo=foeplaneboxx.m_foeplane.begin();
while(itoo!=foeplaneboxx.m_foeplane.end())
{
	if((*itoo)->isgunnerfoeplane(*ito)==true)
	{
		delete(*ito);
		ito=gunnerboxx.m_gunner.erase(ito);
		flag=false;
			(*itoo)->downblood();

	if((*itoo)->isboom())
	{
		
		foeboomboxx.m_boomplane.push_back(*itoo);

	 itoo=foeplaneboxx.m_foeplane.erase(itoo);
	}
	break;

}
	itoo++;
}
if(flag==true)
	ito++;
else
	flag=true;
}

   }