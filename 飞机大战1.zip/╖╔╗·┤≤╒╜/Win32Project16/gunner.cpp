#include "gunner.h"


gunner::gunner(void)
{
	  m_gunner=0;
	  x=0;
	  y=0;
}


gunner::~gunner(void)
{
	DeleteObject(m_gunner);
	  m_gunner=0;
}
 void gunner::initgunner(HINSTANCE hins,int x1,int y1)
 {
	 m_gunner=LoadBitmap(hins,MAKEINTRESOURCE(IDB_gunner));
	 x=x1+27;
	 y=y1-9;
 }
   void gunner::movegunnner()
   {
y=y-10;
   }
   void gunner::showgunner(HDC hdc)
   {
	   HDC menhdc =CreateCompatibleDC(hdc);
	   SelectObject(menhdc,m_gunner);
	   BitBlt(hdc,x,y,6,9,menhdc,0,0,SRCAND);
	   DeleteDC(menhdc);
   }
