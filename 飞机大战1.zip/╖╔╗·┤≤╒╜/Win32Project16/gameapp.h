#pragma once
#include<windows.h>
#define declass(ThisClass)\
	gameapp*getgame()\
 {\
 	return  new ThisClass;\
 }

class gameapp
{
protected:
	HINSTANCE m_hins;
	HWND m_hwnd;
public:
	gameapp()
	{
m_hins=0;
m_hwnd=0;
	}
public:
	virtual~gameapp()
	{

	}
public:
	void sethandle(HINSTANCE hins,HWND hwnd)
	{
		m_hins=hins;
			m_hwnd=hwnd;
	}
public:
	virtual void creategame()//��ҪHINSTACHE
	{

	}
	virtual void drawgame()//HWND
	{

	}
	virtual void rungame(WPARAM timerid)//��ҪWPARAM
	{

	}
	virtual void keydowngame(WPARAM key)//��ҪWPARAM
	{

	}
	virtual void keyupgame(WPARAM key)//��ҪWPARAM
	{

	}
	virtual void lbuttonupgame(POINT point)//��ҪLPARAM
	{

	}
	virtual void lbuttondowngame(POINT point)//��ҪLPARAM
	{

	}
	virtual void mousemovegame(POINT point)//��ҪLPARAM
	{

	}


};