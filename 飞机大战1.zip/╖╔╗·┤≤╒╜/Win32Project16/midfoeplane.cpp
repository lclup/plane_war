#include "midfoeplane.h"


midfoeplane::midfoeplane(void)
{
}


midfoeplane::~midfoeplane(void)
{
}
bool midfoeplane::isgunnerfoeplane(gunner*pgunner)
  {
	 if(pgunner->x>=x&&pgunner->x<=x+70&&pgunner->y>=y&&pgunner->y<=y+90)
	  return true;
	 return false;
  }
  bool midfoeplane::ishitplayer(player&plane)
  {
	  //x+30,y
	      if(plane.x+30>=x&&plane.x+30<=x+70&&plane.y>=y&&plane.y<=y+90)
	   {
		   return true;
	   }
	   //x+60.y+50
		      if(plane.x+60>=x&&plane.x+60<=x+70&&plane.y+50>=y&&plane.y+50<=y+90)
	   {
		   return true;
	   }
	   //x,y+50;
	   if(plane.x>=x&&plane.x<=x+70&&plane.y+50>=y&&plane.y+50<=y+90)
	   {
		   return true;
	   }
	   return false;
  }
  void midfoeplane::initfoepalne(HINSTANCE hins)
  {
x=rand()%310;
y=-90;
blood=3;
showID=2;
bitfoeplane=LoadBitmap(hins,MAKEINTRESOURCE(IDB_mid));
  }
  void midfoeplane::showfoeplane(HDC hdc)
  {
	  HDC hdcmen=CreateCompatibleDC(hdc);
	  SelectObject(hdcmen,bitfoeplane);
	  BitBlt(hdc,x,y,70,90,hdcmen,0,(2-showID)*90,SRCAND);
	  DeleteDC(hdcmen);
  }
  void midfoeplane::movefoeplane()
  {
y=y+4;
  }