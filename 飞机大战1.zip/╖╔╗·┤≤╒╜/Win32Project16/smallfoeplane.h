#pragma once
#include "foeplane.h"
class smallfoeplane :
	public foeplane
{
public:
	smallfoeplane(void);
	~smallfoeplane(void);
	 bool isgunnerfoeplane(gunner*pgunner);
	 bool ishitplayer(player&plane);
	 void initfoepalne(HINSTANCE hins);
	 void showfoeplane(HDC hdc);
	 void movefoeplane();
};

