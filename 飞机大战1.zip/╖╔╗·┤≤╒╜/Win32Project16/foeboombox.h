#pragma once
#include"sys.h"
#include"foeplane.h"
class foeboombox
{
public:
	foeboombox(void);
	~foeboombox(void);
public:
	 list<foeplane*>m_boomplane;
public:
	  void allboomshow(HDC hdc);
	  void changeshowID();

};

