#pragma once
#include "gameapp.h"
#include"background.h"
#include"player.h"
#include"gunnerbox.h"
#include"foepalnebox.h"
#include"foeboombox.h"
 
class planeapp :
	public gameapp
{
public:
	planeapp(void);
	~planeapp(void);
public:
   background backk;
   player playerr;
    gunnerbox gunnerboxx;
	foepalnebox foeplaneboxx;
	 foeboombox foeboomboxx;
public:
   bool isgameover();
   virtual void creategame();
   virtual void drawgame();
   virtual void keydowngame(WPARAM pa);
   virtual void rungame(WPARAM wp);
   void gunnerhitplane();
};

