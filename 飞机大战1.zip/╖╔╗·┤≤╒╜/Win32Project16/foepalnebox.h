#pragma once
#include"sys.h"
#include"foeplane.h"
#include"midfoeplane.h"
#include"smallfoeplane.h"
#include"bigfoeplane.h"
class foepalnebox
{
public:
	foepalnebox(void);
	~foepalnebox(void);
public:
	list<foeplane*> m_foeplane;
public:

	void allmove();
	 void allshow(HDC hdc);
	 void ctreatefoeplane(HINSTANCE hins);

};

