#pragma once
#include"sys.h"
#include"gunner.h"
#include"player.h"
class foeplane
{
public:
	foeplane(void);
	virtual~foeplane(void);
public:
	 HBITMAP bitfoeplane;
	 int blood;
	 int showID;
	int x;
	int y;
public:
	 bool isboom();
	 virtual bool isgunnerfoeplane(gunner*pgunner)=0;
	 virtual bool ishitplayer(player&plane)=0;
	 virtual void initfoepalne(HINSTANCE hins)=0;
	 virtual void showfoeplane(HDC hdc)=0;
	 virtual void movefoeplane()=0;
	 void downblood();

};

