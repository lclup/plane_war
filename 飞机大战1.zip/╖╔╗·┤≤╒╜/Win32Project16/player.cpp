#include "player.h"



player::player(void)
{ 
	m_player=0;
	m_gunnertype=0;
	x=0;
	y=0;
}


player::~player(void)
{
	DeleteObject(m_player);
	m_player=0;
}
 void player::initplayer(HINSTANCE hins)
 {
m_player=LoadBitmap(hins,MAKEINTRESOURCE(IDB_player));
x=160;
y=490;
 }
	 void player::moveplayer(int fx)
	 {
switch(fx)
{
case VK_UP:
	y-=5;
	break;
	case VK_DOWN:
	y+=5;
	break;
	case VK_LEFT:
	x-=5;
	break;
	case VK_RIGHT:
	x+=5;
	break;

}

	 }
	 void player::sendgunner(HINSTANCE hins,gunnerbox&gunnerb)
	 {
		 gunner*gunn =new gunner;
		 gunn->initgunner(hins,x,y);
		 gunnerb.m_gunner.push_back(gunn);


	 }
	 void player::showplayer(HDC hdc)
	 {
HDC hdcmen=CreateCompatibleDC(hdc);
SelectObject(hdcmen,m_player);
BitBlt(hdc,x,y,60,60,hdcmen,0,0,SRCAND);
DeleteDC(hdcmen);

	 }
