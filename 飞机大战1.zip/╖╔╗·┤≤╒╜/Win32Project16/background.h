#pragma once
#include"sys.h"
class background
{
public:
	HBITMAP m_backdown;
	HBITMAP m_backup;
	int x;
	int y;
public:
	background(void);
	~background(void);
public:
    void initback(HINSTANCE hins);
    void moveback();
    void showback(HDC hdc);
};

